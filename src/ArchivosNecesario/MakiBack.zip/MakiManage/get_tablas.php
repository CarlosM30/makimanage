<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Conexión a la base de datos
$conn = new mysqli("localhost", "root", "", "makimanage", 3307);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

// Listado de tablas que se excluyen
$excluir = ['usuarios'];

// Obtener todas las tablas
$query = "SHOW TABLES";
$result = $conn->query($query);

$tablas = [];
while ($row = $result->fetch_array()) {
    $nombreTabla = $row[0];
    if (!in_array($nombreTabla, $excluir)) {
        $tablas[] = $nombreTabla;
    }
}

echo json_encode(['status' => 'success', 'tablas' => $tablas]);
$conn->close();
?>
