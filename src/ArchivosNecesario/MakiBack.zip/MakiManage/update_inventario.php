<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "maki", 3307);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión a la base de datos']);
    exit();
}

$data = json_decode(file_get_contents("php://input"));
$producto_id = intval($data->producto_id ?? 0);
$cantidadARestar = intval($data->cantidad ?? 0);

if ($producto_id <= 0 || $cantidadARestar <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos o inválidos']);
    exit();
}

// Obtener cantidad actual
$check = $conn->prepare("SELECT cantidad FROM inventario WHERE producto_id = ?");
$check->bind_param("i", $producto_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Producto no encontrado']);
    exit();
}

$row = $result->fetch_assoc();
$nuevaCantidad = intval($row['cantidad']) - $cantidadARestar;

if ($nuevaCantidad < 0) {
    echo json_encode(['status' => 'error', 'message' => 'No hay suficiente cantidad disponible']);
    exit();
}

// Actualizar
$update = $conn->prepare("UPDATE inventario SET cantidad = ? WHERE producto_id = ?");
$update->bind_param("ii", $nuevaCantidad, $producto_id);

if ($update->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Cantidad actualizada correctamente']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al actualizar: ' . $conn->error]);
}

$conn->close();
?>
