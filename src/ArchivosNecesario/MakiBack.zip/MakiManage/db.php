<?php
$host = "localhost";
$user = "root";  // Usuario de MySQL
$pass = "";      // Sin contraseña por defecto en XAMPP
$dbname = "sushidorado";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Error de conexión: " . $conn->connect_error]));
}
?>
