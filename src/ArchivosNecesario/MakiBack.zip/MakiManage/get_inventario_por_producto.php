<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Conexión fallida: " . $conn->connect_error]));
}

$producto_id = isset($_GET['producto_id']) ? intval($_GET['producto_id']) : 0;

if ($producto_id <= 0) {
    die(json_encode(["status" => "error", "message" => "ID de producto no válido"]));
}

$sql = "SELECT i.id, i.cantidad, i.fecha_ingreso, i.fecha_caducidad,
               p.nombre AS producto_nombre, p.unidad,
               c.nombre AS categoria_nombre
        FROM inventario i
        JOIN productos p ON i.producto_id = p.id
        JOIN categorias c ON p.categoria_id = c.id
        WHERE i.producto_id = ?
        ORDER BY i.fecha_caducidad ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $producto_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die(json_encode(["status" => "error", "message" => "Error en la consulta: " . $conn->error]));
}

$inventario = [];
while ($row = $result->fetch_assoc()) {
    $inventario[] = $row;
}

echo json_encode([
    "status" => "success",
    "inventario" => $inventario
]);

$conn->close();
?>