<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die(json_encode([
        'status' => 'error',
        'message' => 'Conexión fallida: ' . $conn->connect_error
    ]));
}

$query = "
    SELECT 
        p.nombre AS Producto,
        c.nombre AS categoria,
        IFNULL(i.cantidad, 0) AS Cantidad,
        i.fecha_caducidad,
        p.unidad
    FROM productos p
    JOIN categorias c ON p.categoria_id = c.id
    LEFT JOIN inventario i ON p.id = i.producto_id
    ORDER BY c.nombre, p.nombre
";

$result = $conn->query($query);

if ($result) {
    $productos = [];
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }
    echo json_encode([
        'status' => 'success',
        'productos' => $productos
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Error al obtener el inventario: ' . $conn->error
    ]);
}

$conn->close();
?>