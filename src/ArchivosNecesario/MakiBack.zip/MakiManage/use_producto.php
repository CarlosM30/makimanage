<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Configuración de la base de datos
$host = 'localhost';
$db   = 'maki';
$user = 'root';
$pass = '';
$port = 3306;
$charset = 'utf8mb4';

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;port=$port;charset=$charset", 
        $user, 
        $pass, 
        $options
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Error de conexión a la base de datos',
        'details' => $e->getMessage()
    ]);
    exit;
}

// Manejar preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Obtener datos del request
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['producto_id']) || !isset($input['cantidad'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Datos incompletos o inválidos'
    ]);
    exit;
}

$productoId = (int)$input['producto_id'];
$cantidad = (int)$input['cantidad'];

try {
    $pdo->beginTransaction();

    // 1. Verificar stock disponible
    $stmt = $pdo->prepare("SELECT SUM(cantidad) as total FROM inventario WHERE producto_id = ?");
    $stmt->execute([$productoId]);
    $stock = $stmt->fetch()['total'];

    if ($stock < $cantidad) {
        throw new Exception("Stock insuficiente");
    }

    // 2. Actualizar inventario
    $stmt = $pdo->prepare("
        UPDATE inventario 
        SET cantidad = cantidad - ? 
        WHERE producto_id = ? 
        ORDER BY COALESCE(fecha_caducidad, '9999-12-31') ASC
        LIMIT 1
    ");
    $stmt->execute([$cantidad, $productoId]);

    // 3. Eliminar registros con cantidad <= 0
    $pdo->prepare("DELETE FROM inventario WHERE cantidad <= 0")->execute();

    $pdo->commit();

    echo json_encode([
        'status' => 'success',
        'message' => 'Inventario actualizado'
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>