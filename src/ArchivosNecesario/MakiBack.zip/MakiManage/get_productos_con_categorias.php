<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Conexión fallida: " . $conn->connect_error]));
}

$sql = "SELECT p.id, p.nombre, p.unidad, c.id AS categoria_id, c.nombre AS categoria_nombre 
        FROM productos p
        JOIN categorias c ON p.categoria_id = c.id
        ORDER BY c.nombre, p.nombre";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(["status" => "error", "message" => "Error en la consulta: " . $conn->error]));
}

$productos = [];
while ($row = $result->fetch_assoc()) {
    $productos[] = $row;
}

echo json_encode([
    "status" => "success",
    "productos" => $productos
]);

$conn->close();
?>