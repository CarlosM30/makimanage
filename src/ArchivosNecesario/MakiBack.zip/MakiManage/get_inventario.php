<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

// DEBUG opcional
file_put_contents("debug_categoria.txt", json_encode($data) . PHP_EOL, FILE_APPEND);

$categoria_id = intval($data->categoria_id ?? 0);

if ($categoria_id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Categoría inválida']);
    exit();
}

$sql = "
SELECT 
    prod.id AS producto_id,
    prod.nombre AS Producto,
    prod.unidad AS Unidad,
    cat.nombre AS Categoria,
    IFNULL(inv.cantidad, 0) AS Cantidad,
    inv.fecha_caducidad AS Fecha_Caducidad
FROM productos prod
LEFT JOIN inventario inv ON prod.id = inv.producto_id
INNER JOIN categorias cat ON prod.categoria_id = cat.id
WHERE prod.categoria_id = ?
ORDER BY prod.nombre
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $categoria_id);
$stmt->execute();
$result = $stmt->get_result();

$productos = [];
while ($row = $result->fetch_assoc()) {
    $productos[] = $row;
}

echo json_encode([
    'status' => 'success',
    'productos' => $productos
]);

$conn->close();
?>
