<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Conexión fallida: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id)) {
    die(json_encode(["status" => "error", "message" => "ID de usuario no proporcionado"]));
}

$sql = "DELETE FROM usuarios WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $data->id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Usuario eliminado correctamente"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error al eliminar usuario"]);
}

$conn->close();
?>