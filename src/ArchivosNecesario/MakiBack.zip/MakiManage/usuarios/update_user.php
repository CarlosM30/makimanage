<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Conexión fallida: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"));

// Validar datos
if (!isset($data->id) || !isset($data->usuario) || !isset($data->especialidad) || !isset($data->estado)) {
    die(json_encode(["status" => "error", "message" => "Datos incompletos"]));
}

// Preparar consulta
if (!empty($data->contrasena)) {
    $hashed_password = password_hash($data->contrasena, PASSWORD_DEFAULT);
    $sql = "UPDATE usuarios SET usuario=?, contrasena=?, especialidad=?, estado=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $data->usuario, $hashed_password, $data->especialidad, $data->estado, $data->id);
} else {
    $sql = "UPDATE usuarios SET usuario=?, especialidad=?, estado=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $data->usuario, $data->especialidad, $data->estado, $data->id);
}

// Ejecutar consulta
if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Usuario actualizado correctamente"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error al actualizar usuario"]);
}

$conn->close();
?>