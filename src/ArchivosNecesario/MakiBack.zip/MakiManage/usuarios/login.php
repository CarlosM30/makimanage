<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"));
$user = $data->username;
$pass = $data->password;

$sql = "SELECT * FROM usuarios WHERE usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $userData = $result->fetch_assoc();

    if (password_verify($pass, $userData['contrasena'])) {
        echo json_encode([
            'status' => 'success',
            'Especialidad' => $userData['especialidad'],
            'Estado' => $userData['estado']
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Contraseña incorrecta'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Usuario no encontrado'
    ]);
}

$conn->close();
?>
