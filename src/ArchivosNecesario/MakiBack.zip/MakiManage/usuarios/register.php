<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"));
$user = $data->username;
$pass = $data->password;
$specialty = $data->specialty;
$status = "Activo";

// Verificar si el usuario ya existe
$checkSql = "SELECT id FROM usuarios WHERE usuario = ?";
$checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("s", $user);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'El usuario ya existe'
    ]);
    $checkStmt->close();
    $conn->close();
    exit;
}
$checkStmt->close();

// Hashear la contraseña antes de guardar
$hashedPassword = password_hash($pass, PASSWORD_DEFAULT);

// Insertar el nuevo usuario
$sql = "INSERT INTO usuarios (usuario, contrasena, especialidad, estado) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $user, $hashedPassword, $specialty, $status);

if ($stmt->execute()) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Usuario registrado con éxito'
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Error al registrar el usuario'
    ]);
}

$conn->close();
?>
