<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Conexión fallida: " . $conn->connect_error]));
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->producto_id) || !isset($data->cantidad)) {
    die(json_encode(["status" => "error", "message" => "Datos incompletos"]));
}

$producto_id = intval($data->producto_id);
$cantidad = intval($data->cantidad);

if ($producto_id <= 0 || $cantidad < 0) {
    die(json_encode(["status" => "error", "message" => "Datos no válidos"]));
}

// Actualizar todas las entradas de inventario para este producto
$sql = "UPDATE inventario SET cantidad = ? WHERE producto_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $cantidad, $producto_id);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Inventario actualizado correctamente"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Error al actualizar el inventario: " . $conn->error
    ]);
}

$conn->close();
?>