<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");


$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

// Leer entrada JSON
$data = json_decode(file_get_contents("php://input"), true);
$categoria_id = intval($data['categoria_id'] ?? 0);

if ($categoria_id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Categoría inválida']);
    exit();
}

$stmt = $conn->prepare("SELECT id, nombre FROM productos WHERE categoria_id = ? ORDER BY nombre");
$stmt->bind_param("i", $categoria_id);
$stmt->execute();
$result = $stmt->get_result();

$productos = [];
while ($row = $result->fetch_assoc()) {
    $productos[] = [
        'id' => $row['id'],
        'nombre' => $row['nombre']
    ];
}

echo json_encode(['status' => 'success', 'productos' => $productos]);
$conn->close();
?>
