<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión a la base de datos']);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

$categoria_nombre = $data->categoria ?? '';
$producto = $data->producto ?? '';
$unidad = $data->unidad ?? '';
$cantidad = $data->cantidad ?? 0;
$fecha_caducidad = $data->fecha_caducidad ?? null;

// Validaciones básicas
if (!$categoria_nombre || !$producto || !$unidad || $cantidad <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Todos los campos son obligatorios']);
    exit();
}

// 1. Buscar ID de categoría
$stmt = $conn->prepare("SELECT id FROM categorias WHERE nombre = ?");
$stmt->bind_param("s", $categoria_nombre);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Categoría no encontrada']);
    exit();
}

$categoria = $result->fetch_assoc();
$categoria_id = $categoria['id'];

// 2. Insertar producto (si no existe uno igual en esa categoría)
$stmt = $conn->prepare("INSERT INTO productos (nombre, unidad, categoria_id) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $producto, $unidad, $categoria_id);
if (!$stmt->execute()) {
    echo json_encode(['status' => 'error', 'message' => 'Error al insertar producto: ' . $stmt->error]);
    exit();
}
$producto_id = $stmt->insert_id;

// 3. Insertar en inventario
$stmt = $conn->prepare("INSERT INTO inventario (producto_id, cantidad, fecha_caducidad) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $producto_id, $cantidad, $fecha_caducidad);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Producto y entrada de inventario agregados correctamente']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al insertar en inventario: ' . $stmt->error]);
}

$conn->close();
?>
