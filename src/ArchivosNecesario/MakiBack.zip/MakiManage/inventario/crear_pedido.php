<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "maki";
$port = 3306;

try {
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    
    if ($conn->connect_error) {
        throw new Exception("Error de conexión: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }

    $json = file_get_contents('php://input');
    $data = json_decode($json);

    if (!$data) {
        throw new Exception("Datos JSON no válidos");
    }

    $proveedor_id = $data->proveedor_id ?? null;
    $productos = $data->productos ?? [];

    if (!$proveedor_id || empty($productos)) {
        throw new Exception("Datos incompletos: proveedor_id o productos faltantes");
    }

    // Verificar que el proveedor existe
    $stmt = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND estado = 'Activo'");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows === 0) {
        throw new Exception("Proveedor no existe o está inactivo");
    }
    $stmt->close();

    // Iniciar transacción
    $conn->begin_transaction();

    // 1. Insertar en la tabla 'pedidos'
    $stmt = $conn->prepare("INSERT INTO pedidos (proveedor_id, fecha_pedido, estado) VALUES (?, NOW(), 'Pendiente')");
    if (!$stmt) {
        throw new Exception("Error al preparar consulta: " . $conn->error);
    }

    $stmt->bind_param("i", $proveedor_id);
    if (!$stmt->execute()) {
        throw new Exception("Error al crear pedido: " . $stmt->error);
    }

    $pedido_id = $conn->insert_id;
    $stmt->close();

    // 2. Preparar inserción en detalle_pedido
    $detalle_stmt = $conn->prepare("INSERT INTO detalle_pedido (pedido_id, producto_id, cantidad, unidad) VALUES (?, ?, ?, ?)");
    if (!$detalle_stmt) {
        throw new Exception("Error al preparar detalle: " . $conn->error);
    }

    // 3. Para cada producto, obtener o crear el producto y luego insertar en detalle_pedido
    foreach ($productos as $item) {
        $producto_nombre = $conn->real_escape_string($item->producto ?? '');
        $cantidad = intval($item->cantidad ?? 0);
        $unidad = $conn->real_escape_string($item->unidad ?? '');

        if (empty($producto_nombre) || $cantidad <= 0 || empty($unidad)) {
            continue; // Saltar productos inválidos
        }

        // Buscar el producto por nombre
        $producto_result = $conn->query("SELECT id FROM productos WHERE nombre = '$producto_nombre' LIMIT 1");
        
        if ($producto_result && $producto_result->num_rows > 0) {
            // Producto existe, obtener su ID
            $producto_row = $producto_result->fetch_assoc();
            $producto_id = $producto_row['id'];
        } else {
            // Producto no existe, crearlo (opcional)
            // Primero necesitamos una categoría por defecto
            $categoria_default = 1; // Ajusta esto según tu base de datos
            
            if (!$conn->query("INSERT INTO productos (nombre, unidad, categoria_id) VALUES ('$producto_nombre', '$unidad', $categoria_default)")) {
                throw new Exception("Error al crear producto: " . $conn->error);
            }
            $producto_id = $conn->insert_id;
        }

        // Insertar en detalle_pedido
        $detalle_stmt->bind_param("iiis", $pedido_id, $producto_id, $cantidad, $unidad);
        if (!$detalle_stmt->execute()) {
            throw new Exception("Error al insertar detalle de pedido: " . $detalle_stmt->error);
        }
    }

    $detalle_stmt->close();
    $conn->commit();

    http_response_code(201);
    echo json_encode([
        'status' => 'success',
        'message' => 'Pedido creado correctamente',
        'pedido_id' => $pedido_id,
        'detalle_pedido' => count($productos) . ' productos registrados'
    ]);

} catch (Exception $e) {
    if (isset($conn) && $conn->in_transaction) {
        $conn->rollback();
    }

    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'debug' => [
            'proveedor_id' => $proveedor_id ?? null,
            'productos_count' => count($productos)
        ]
    ]);
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>