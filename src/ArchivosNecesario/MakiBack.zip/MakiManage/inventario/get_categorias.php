<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Conexión
$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

// Consulta
$query = "SELECT id, nombre FROM categorias";
$result = $conn->query($query);

$categorias = [];
while ($row = $result->fetch_assoc()) {
    $categorias[] = [
        'id' => $row['id'],
        'nombre' => $row['nombre']
    ];
}

echo json_encode(['status' => 'success', 'categorias' => $categorias]);
$conn->close();
?>
