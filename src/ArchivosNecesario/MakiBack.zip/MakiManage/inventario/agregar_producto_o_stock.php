<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

$nombre = trim($data['nombre'] ?? '');
$unidad = trim($data['unidad'] ?? '');
$categoria_id = intval($data['categoria_id'] ?? 0);
$cantidad = intval($data['cantidad'] ?? 0);
$fecha_caducidad = $data['fecha_caducidad'] ?? null;

if ($nombre === '' || $unidad === '' || $categoria_id <= 0 || $cantidad <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos o inválidos']);
    exit();
}

// Buscar si ya existe el producto con ese nombre y categoría
$check = $conn->prepare("SELECT id FROM productos WHERE nombre = ? AND categoria_id = ?");
$check->bind_param("si", $nombre, $categoria_id);
$check->execute();
$check->bind_result($producto_id);
$existe = $check->fetch();
$check->close();

if (!$existe) {
    // Insertar nuevo producto
    $insertProd = $conn->prepare("INSERT INTO productos (nombre, unidad, categoria_id) VALUES (?, ?, ?)");
    $insertProd->bind_param("ssi", $nombre, $unidad, $categoria_id);
    if ($insertProd->execute()) {
        $producto_id = $insertProd->insert_id;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo registrar el producto']);
        exit();
    }
    $insertProd->close();
}

// Insertar en inventario
$insertInv = $conn->prepare("INSERT INTO inventario (producto_id, cantidad, fecha_caducidad) VALUES (?, ?, ?)");
$insertInv->bind_param("iis", $producto_id, $cantidad, $fecha_caducidad);
if ($insertInv->execute()) {
    echo json_encode(['status' => 'success', 'message' => $existe ? 'Stock agregado al producto existente' : 'Producto y stock registrado']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No se pudo registrar en inventario']);
}
$insertInv->close();
$conn->close();
?>
