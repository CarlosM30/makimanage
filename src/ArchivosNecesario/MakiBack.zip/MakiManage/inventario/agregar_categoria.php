<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

$data = json_decode(file_get_contents("php://input"));
$nombre = trim($data->nombre ?? '');
$descripcion = trim($data->descripcion ?? '');

// Validación básica
if (!$nombre || !preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑ0-9\s]+$/', $nombre)) {
    echo json_encode(['status' => 'error', 'message' => 'Nombre de categoría inválido']);
    exit();
}

// Escapar y verificar si ya existe
$nombre = $conn->real_escape_string($nombre);
$descripcion = $conn->real_escape_string($descripcion);

$check = $conn->prepare("SELECT id FROM categorias WHERE nombre = ?");
$check->bind_param("s", $nombre);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode(['status' => 'error', 'message' => 'La categoría ya existe']);
    $check->close();
    $conn->close();
    exit();
}
$check->close();

// Insertar categoría con descripción
$insert = $conn->prepare("INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)");
$insert->bind_param("ss", $nombre, $descripcion);

if ($insert->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Categoría creada exitosamente']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al guardar la categoría']);
}

$insert->close();
$conn->close();
?>
