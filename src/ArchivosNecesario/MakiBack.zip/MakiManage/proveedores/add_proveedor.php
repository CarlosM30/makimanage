<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión a la base de datos']);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

$nombre = $data->nombre ?? '';
$contacto = $data->contacto ?? '';
$telefono = $data->telefono ?? '';
$email = $data->email ?? '';
$ciudad = $data->ciudad ?? '';
$tipo_producto = $data->tipo_producto ?? '';
$estado = $data->estado ?? 'Activo';

// Validación básica
if (empty($nombre) || empty($telefono) || empty($email) || empty($ciudad) || empty($tipo_producto)) {
    echo json_encode(['status' => 'error', 'message' => 'Todos los campos obligatorios deben estar completos']);
    exit();
}

$stmt = $conn->prepare("INSERT INTO proveedores (nombre, contacto, telefono, email, ciudad, tipo_producto, estado) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $nombre, $contacto, $telefono, $email, $ciudad, $tipo_producto, $estado);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Proveedor registrado correctamente']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al registrar proveedor: ' . $conn->error]);
}

$conn->close();
?>
