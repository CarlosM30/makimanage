<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

$query = "SELECT id, nombre, contacto, telefono, email, ciudad FROM proveedores WHERE estado = 'Activo'";
$result = $conn->query($query);

$proveedores = [];
while ($row = $result->fetch_assoc()) {
    $proveedores[] = $row;
}

echo json_encode(['status' => 'success', 'proveedores' => $proveedores]);
$conn->close();
?>
