<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "maki", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

$categoria_id = isset($_GET['categoria_id']) ? intval($_GET['categoria_id']) : 0;

if ($categoria_id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'ID de categoría no válido']);
    exit();
}

// Consulta para obtener el inventario de una categoría específica
$query = "SELECT 
            p.id AS producto_id,
            p.nombre AS producto_nombre,
            p.unidad,
            SUM(i.cantidad) AS cantidad_total,
            MIN(i.fecha_caducidad) AS proxima_caducidad
          FROM productos p
          JOIN inventario i ON p.id = i.producto_id
          WHERE p.categoria_id = ?
          GROUP BY p.id
          ORDER BY p.nombre";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $categoria_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo json_encode(['status' => 'error', 'message' => 'Error en la consulta: ' . $conn->error]);
    exit();
}

$inventario = [];
while ($row = $result->fetch_assoc()) {
    $inventario[] = $row;
}

echo json_encode([
    'status' => 'success',
    'inventario' => $inventario
]);

$conn->close();
?>