<?php
// Mostrar errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// CORS para React
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Methods: POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type");
    http_response_code(200);
    exit();
}
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Conexión
$conn = new mysqli("localhost", "root", "", "makimanage", 3306);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión']);
    exit();
}

// Leer datos del frontend
$data = json_decode(file_get_contents("php://input"));
$nombreTabla = $data->nombre ?? '';
$conFecha = $data->con_fecha ?? false;

// Validar nombre de tabla (solo letras, números y guión bajo, no empezar con número)
if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $nombreTabla)) {
    echo json_encode(['status' => 'error', 'message' => 'Nombre de tabla inválido']);
    exit();
}

// Escapar el nombre para evitar inyección
$nombreTabla = $conn->real_escape_string($nombreTabla);

// Verificar si ya existe
$check_sql = "SHOW TABLES LIKE '$nombreTabla'";
$res = $conn->query($check_sql);

if ($res && $res->num_rows > 0) {
    echo json_encode(['status' => 'error', 'message' => 'La tabla ya existe']);
    exit();
}

// Crear tabla con o sin Fecha_C
if ($conFecha) {
    $sql = "CREATE TABLE `$nombreTabla` (
        Producto VARCHAR(100),
        Unidad VARCHAR(50),
        Cantidad INT,
        Fecha_C DATE
    )";
} else {
    $sql = "CREATE TABLE `$nombreTabla` (
        Producto VARCHAR(100),
        Unidad VARCHAR(50),
        Cantidad INT
    )";
}

// Ejecutar creación
if ($conn->query($sql)) {
    echo json_encode(['status' => 'success', 'message' => "Tabla '$nombreTabla' creada exitosamente"]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al crear la tabla: ' . $conn->error]);
}

$conn->close();
?>
