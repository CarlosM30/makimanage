<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Configuración de conexión
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "maki";
$port = 3306;

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode([
        "status" => "error",
        "message" => "Error de conexión a la base de datos",
        "details" => $conn->connect_error
    ]));
}

// Consulta para obtener categorías
$sql = "SELECT id, nombre FROM categorias ORDER BY nombre";
$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    die(json_encode([
        "status" => "error",
        "message" => "Error en la consulta SQL",
        "details" => $conn->error
    ]));
}

$categorias = [];
while ($row = $result->fetch_assoc()) {
    $categorias[] = $row;
}

// Respuesta exitosa
echo json_encode([
    "status" => "success",
    "categorias" => $categorias
]);

$conn->close();
?>